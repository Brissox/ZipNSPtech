package com.nspTECH.carrito_compras.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nspTECH.carrito_compras.model.carrito_compra;

public interface detalleRepository extends JpaRepository<carrito_compra, Long> {

}
