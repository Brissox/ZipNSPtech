package com.nspTECH.logistica_envios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogisticaEnviosApplicationTests {

	@Test
	void contextLoads() {
	}

}
