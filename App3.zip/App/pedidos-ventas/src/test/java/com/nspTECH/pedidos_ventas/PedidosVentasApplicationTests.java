package com.nspTECH.pedidos_ventas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
