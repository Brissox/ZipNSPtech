package com.nspTECH.autenticacion_autorizacion.model_a_a;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="USUARIO")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class usuario{

    @Id
    private Long rut;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String mail;
    
    @Column(nullable = false)
    private Integer idcurso;
}
