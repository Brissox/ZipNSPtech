package com.nspTECH.autenticacion_autorizacion.repository_a_a;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nspTECH.autenticacion_autorizacion.model_a_a.usuario;



public interface UsuarioRespository extends JpaRepository<usuario, Long> {

}
