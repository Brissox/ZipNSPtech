package com.nspTECH.promociones_descuentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromocionesDescuentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
