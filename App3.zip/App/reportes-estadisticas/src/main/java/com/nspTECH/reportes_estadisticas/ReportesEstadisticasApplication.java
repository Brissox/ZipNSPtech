package com.nspTECH.reportes_estadisticas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportesEstadisticasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportesEstadisticasApplication.class, args);
	}

}
