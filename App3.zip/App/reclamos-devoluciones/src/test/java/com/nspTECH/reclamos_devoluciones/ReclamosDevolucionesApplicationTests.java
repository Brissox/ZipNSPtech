package com.nspTECH.reclamos_devoluciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReclamosDevolucionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
