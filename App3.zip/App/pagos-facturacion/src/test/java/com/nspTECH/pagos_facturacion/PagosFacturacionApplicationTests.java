package com.nspTECH.pagos_facturacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagosFacturacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
