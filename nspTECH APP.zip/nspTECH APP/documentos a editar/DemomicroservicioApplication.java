package cl.duoc.demomicroservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomicroservicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomicroservicioApplication.class, args);
	}

}
