package com.nspTECH.carrito_compras.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nspTECH.carrito_compras.DTO.carritoProductosDTO;
import com.nspTECH.carrito_compras.DTO.productosDTO;
import com.nspTECH.carrito_compras.model.carrito_compra;
import com.nspTECH.carrito_compras.services.detalleServices;

@RestController
@RequestMapping(("/api/v1/carrito_compra"))

public class detalleController {

    @Autowired

    private detalleServices detalleservices;


    @GetMapping
    public ResponseEntity<?> ListarDetalle(){
        List<carrito_compra> carrito_compra = detalleservices.BuscarTodoDetalle();
            if (carrito_compra.isEmpty()) {
                            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentra el detalle");

            } else {
            return ResponseEntity.ok(carrito_compra);
            }
        }
    
    @GetMapping("/{PRODUCTO_ID}")
    public ResponseEntity<?> BuscarDetalle(@PathVariable Long PRODUCTO_ID){
        try {
            carrito_compra carrito_buscado = detalleservices.BuscarUnDetalle(PRODUCTO_ID);
            return ResponseEntity.ok(carrito_buscado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentran el Pedido");

        }
    }

    @GetMapping("/CarritoVenta/{PRODUCTO_ID}")
    public ResponseEntity<?> carritoProductos(@PathVariable Long PRODUCTO_ID){
        try {
            carrito_compra carritoBuscado = detalleservices.BuscarUnDetalle(PRODUCTO_ID);
            productosDTO productosCarrito = detalleservices.BuscarProducto(carritoBuscado.getPRODUCTO_ID());
            carritoProductosDTO carritoproducto = new carritoProductosDTO();
            carritoproducto.setID_PRODUCTO(carritoBuscado.getPRODUCTO_ID());
            carritoproducto.setVALOR(carritoBuscado.getVALOR());
            carritoproducto.setCANTIDAD(carritoBuscado.getCANTIDAD());
            carritoproducto.setSKU(productosCarrito.getSKU());

            return ResponseEntity.ok(carritoproducto);
        
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentran ");

        }

    }





    @PostMapping
    public ResponseEntity<?> GuardarDetalle(@RequestBody carrito_compra carrito_Guardar){
        try {
            carrito_compra carritoRegistrar = detalleservices.GuardarDetalle(carrito_Guardar);
            return ResponseEntity.ok(carritoRegistrar);
        } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body("No se puede registrar el Pedido");
        }
    }


    @DeleteMapping("/{PRODUCTO_ID}")
        public ResponseEntity<String> EliminarDetalle(@PathVariable Long PRODUCTO_ID){
            try {
                carrito_compra carritoBuscado = detalleservices.BuscarUnDetalle(PRODUCTO_ID);
                detalleservices.EliminarDetalle(PRODUCTO_ID);
                return ResponseEntity.status(HttpStatus.OK).body("Se elimina detalle");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Detalle no esta registrado");
            }
        }
    @PutMapping("/{PRODUCTO_ID}")
    public ResponseEntity<?> ActualizarDetalle(@PathVariable Long PRODUCTO_ID, @RequestBody carrito_compra carritoActualizar){
        try {
            carrito_compra carritoActualizado = detalleservices.BuscarUnDetalle(PRODUCTO_ID);
            carritoActualizado.setCANTIDAD(carritoActualizar.getCANTIDAD());
            carritoActualizado.setPRODUCTO_ID(carritoActualizar.getPRODUCTO_ID());
            carritoActualizado.setVALOR(carritoActualizar.getVALOR());
        
            detalleservices.GuardarDetalle(carritoActualizado);
            return ResponseEntity.ok(carritoActualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Detalle no esta registrado");
        }
    }
    }


