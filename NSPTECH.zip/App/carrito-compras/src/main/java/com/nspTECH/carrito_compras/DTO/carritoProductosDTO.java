package com.nspTECH.carrito_compras.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class carritoProductosDTO {
    
    private long ID_PRODUCTO;
    private String NOMBRE;
    private Long VALOR;
    private Long CANTIDAD;
    private Long PRECIO;
    private String SKU;

}
