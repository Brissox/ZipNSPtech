package com.nspTECH.pagos_facturacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagosFacturacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagosFacturacionApplication.class, args);
	}

}
