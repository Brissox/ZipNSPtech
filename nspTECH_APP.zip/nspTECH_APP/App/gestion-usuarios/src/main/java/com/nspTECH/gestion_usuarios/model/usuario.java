package com.nspTECH.gestion_usuarios.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="CLIENTE")
@Data
@AllArgsConstructor
@NoArgsConstructor




public class usuario {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name= "ID_CLIENTE")
    private long ID_CLIENTE;

    @Column(name= "NOMBRE",nullable= false , length = 100)
    private String NOMBRE;
    
    @Column(name = "APELLIDO",nullable= true , length = 100)
    private String APELLIDO;

    @Column(name = "DIRECCION",nullable= false , length = 100)
    private String DIRECCION;





}
