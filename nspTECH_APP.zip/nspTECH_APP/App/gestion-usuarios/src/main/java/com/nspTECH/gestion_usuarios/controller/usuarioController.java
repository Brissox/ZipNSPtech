package com.nspTECH.gestion_usuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nspTECH.gestion_usuarios.model.usuario;
import com.nspTECH.gestion_usuarios.services.usuarioServices;




@RestController
@RequestMapping("/api/v1/Usuarios")
public class usuarioController {


@Autowired

    private usuarioServices usuarioservices;

    @GetMapping
    public ResponseEntity<?> ListarUsuarios(){
        List<usuario> usuarios = usuarioservices.BuscarTodoUsuario();
        if (usuarios.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentran dato");
        } else {
            return ResponseEntity.ok(usuarios);
        }
    }
    @GetMapping("/{ID_CLIENTE}")
    public ResponseEntity<?> BuscarProducto(@PathVariable Long ID_CLIENTE){

        try {
            usuario usuarioBuscado = usuarioservices.BuscarUnUsuario(ID_CLIENTE);
            return ResponseEntity.ok(usuarioBuscado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encuentran Producto");
        }
        
    }

    @PostMapping
    public ResponseEntity<?> GuardarUsuario(@RequestBody usuario usuarioGuardar){
       try {
            usuario usuarioRegistrar = usuarioservices.GuardarUsuario(usuarioGuardar);
            return ResponseEntity.ok(usuarioRegistrar);
       } catch (Exception e) {
         return ResponseEntity.status(HttpStatus.CONFLICT).body("No se puede registrar el Producto");
       }
    }
    
    @DeleteMapping("/{ID_CLIENTE}")
        public ResponseEntity<String> EliminarUsuario(@PathVariable Long ID_CLIENTE){
            try {
                usuario usuarioBuscado = usuarioservices.BuscarUnUsuario(ID_CLIENTE);
                usuarioservices.EliminarUsuario(ID_CLIENTE);
                return ResponseEntity.status(HttpStatus.OK).body("Se elimina Usuario");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no esta registrado");
            }
        }
    @PutMapping("/{ID_CLIENTE}") //SOLO PERMITE ACTUALIZAR ESCRIBIENDO TODOS LOS DATOS
        
    public ResponseEntity<?> ActualizarUsuarios(@PathVariable Long ID_CLIENTE, @RequestBody usuario usuarioActualizar){
        try {
            usuario usuarioActualizado = usuarioservices.BuscarUnUsuario(ID_CLIENTE);
            usuarioActualizado.setNOMBRE(usuarioActualizar.getNOMBRE());
            usuarioActualizado.setAPELLIDO(usuarioActualizar.getAPELLIDO());
            usuarioActualizado.setDIRECCION(usuarioActualizar.getDIRECCION());
            usuarioservices.GuardarUsuario(usuarioActualizado);
            return ResponseEntity.ok(usuarioActualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no esta registrado");
        }
    }
    









}
