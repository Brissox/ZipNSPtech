package com.nspTECH.carrito_compras.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nspTECH.carrito_compras.DTO.productosDTO;
import com.nspTECH.carrito_compras.model.carrito_compra;
import com.nspTECH.carrito_compras.repository.detalleRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional


public class detalleServices {


    private final WebClient webclient;

    public detalleServices(WebClient webClient){
        this.webclient = webClient;
    }



    @Autowired
    private detalleRepository detallerepository;


    public productosDTO BuscarProducto(long ID_PRODUCTO){
        productosDTO producto = webclient.get()
                                .uri("/{ID_PRODUCTO}",ID_PRODUCTO)
                                .retrieve()
                                .bodyToMono(productosDTO.class)
                                .block();
        return producto;
    }





    public List<carrito_compra> BuscarTodoDetalle(){
            return detallerepository.findAll();

    }

    public carrito_compra BuscarUnDetalle(Long ID_DETALLE){
        return detallerepository.findById(ID_DETALLE).get();
    }

    public carrito_compra GuardarDetalle(carrito_compra carrito_compra){
        return detallerepository.save(carrito_compra);
    }

    public void EliminarDetalle(Long ID_DETALLE){
        detallerepository.deleteById(ID_DETALLE);

    }




}
