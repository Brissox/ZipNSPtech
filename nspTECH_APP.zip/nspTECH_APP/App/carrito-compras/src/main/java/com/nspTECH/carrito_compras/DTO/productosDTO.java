package com.nspTECH.carrito_compras.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor


public class productosDTO {
    
    
    private long ID_PRODUCTO;
    private String NOMBRE;
    private Long CANTIDAD;
    private Long PRECIO;

}


