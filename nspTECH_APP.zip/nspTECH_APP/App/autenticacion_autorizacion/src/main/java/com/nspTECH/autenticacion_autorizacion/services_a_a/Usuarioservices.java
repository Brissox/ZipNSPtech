package com.nspTECH.autenticacion_autorizacion.services_a_a;

import java.util.List;

import  com.nspTECH.autenticacion_autorizacion.model_a_a.usuario;
import  com.nspTECH.autenticacion_autorizacion.repository_a_a.UsuarioRespository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

@Service
@Transactional





public class Usuarioservices {
    @Autowired
    private UsuarioRespository usuariorepository;

    public List<usuario> BuscarTodo(){
        return usuariorepository.findAll();
    }

    public usuario BuscarUnUsuario(Long rut){
        return usuariorepository.findById(rut).get();
    }

    public usuario Guardar(usuario usuario){
        return usuariorepository.save(usuario);
    }

    public void Eliminar(Long rut){
        usuariorepository.deleteById(rut);
    }
}
