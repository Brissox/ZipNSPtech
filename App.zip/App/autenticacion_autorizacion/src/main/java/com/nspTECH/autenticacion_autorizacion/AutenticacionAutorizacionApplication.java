package com.nspTECH.autenticacion_autorizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutenticacionAutorizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutenticacionAutorizacionApplication.class, args);
	}

}
