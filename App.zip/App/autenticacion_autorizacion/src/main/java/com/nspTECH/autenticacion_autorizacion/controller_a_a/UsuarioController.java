package com.nspTECH.autenticacion_autorizacion.controller_a_a;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nspTECH.autenticacion_autorizacion.model_a_a.usuario;
import com.nspTECH.autenticacion_autorizacion.services_a_a.Usuarioservices;

@RestController
@RequestMapping("/api/v1/Usuarios")

public class UsuarioController {

    @Autowired
    private Usuarioservices usuarioservice;

    @GetMapping
    public ResponseEntity<List<usuario>> Listar(){
        List<usuario> usuarios = usuarioservice.BuscarTodo();
        if(usuarios.isEmpty()){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(usuarios);
        }
    }

    @GetMapping("/{rut}")
    public ResponseEntity<usuario> BuscarUsuario(@PathVariable Long rut){
        try {
            usuario usuario = usuarioservice.BuscarUnUsuario(rut);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping
    public ResponseEntity<usuario> guardar(@RequestBody usuario usuario){
        usuario usuarioNuevo = usuarioservice.Guardar(usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioNuevo);
    }

    @DeleteMapping("/{rut}")
    public ResponseEntity<?> eliminar(@PathVariable Long rut){
        try {
            usuarioservice.Eliminar(rut);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.noContent().build();
        }
    }
    
    @PutMapping("/{rut}")
    public ResponseEntity<usuario> actualizar(@PathVariable Long rut, @RequestBody usuario usuario){
        try {
            usuario usuarioEditar = usuarioservice.BuscarUnUsuario(rut);
            usuarioEditar.setRut(rut);
            usuarioEditar.setNombre(usuario.getNombre());
            usuarioEditar.setMail(usuario.getMail());
            usuarioEditar.setIdcurso(usuario.getIdcurso());

            usuarioservice.Guardar(usuarioEditar);
            return ResponseEntity.ok(usuarioEditar);

        } catch (Exception e) {
            return ResponseEntity.noContent().build();
        }
    }
}
