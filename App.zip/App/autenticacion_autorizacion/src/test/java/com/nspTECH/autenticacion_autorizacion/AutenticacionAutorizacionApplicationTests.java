package com.nspTECH.autenticacion_autorizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacionAutorizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
