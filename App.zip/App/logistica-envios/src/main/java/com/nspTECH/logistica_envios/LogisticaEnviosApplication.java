package com.nspTECH.logistica_envios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogisticaEnviosApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogisticaEnviosApplication.class, args);
	}

}
