package com.nspTECH.pedidos_ventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidosVentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidosVentasApplication.class, args);
	}

}
