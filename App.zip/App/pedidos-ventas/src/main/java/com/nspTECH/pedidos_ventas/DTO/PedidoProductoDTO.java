package com.nspTECH.pedidos_ventas.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class PedidoProductoDTO {

    private long ID_PEDIDO;
    private long DETALLE_ID;
    private String ANOTACIONES;
    private Long IVA;
    private Long VALOR_TOTAL;
    private long ID_PRODUCTO;
    private String NOMBRE;
    private Long CANTIDAD;
    private Long PRECIO;

}
