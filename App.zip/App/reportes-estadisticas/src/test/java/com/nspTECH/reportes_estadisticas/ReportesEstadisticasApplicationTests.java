package com.nspTECH.reportes_estadisticas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportesEstadisticasApplicationTests {

	@Test
	void contextLoads() {
	}

}
