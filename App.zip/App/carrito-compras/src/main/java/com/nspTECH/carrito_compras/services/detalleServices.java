package com.nspTECH.carrito_compras.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nspTECH.carrito_compras.DTO.productosDTO;
import com.nspTECH.carrito_compras.model.carrito_compra;
import com.nspTECH.carrito_compras.repository.detalleRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional


public class detalleServices {


    private final WebClient webclient;

    public detalleServices(WebClient webClient){
        this.webclient = webClient;
    }



    @Autowired
    private detalleRepository detallerepository;


    public productosDTO BuscarProducto(long PRODUCTO_ID){
        productosDTO producto = webclient.get()
                                .uri("/{PRODUCTO_ID}",PRODUCTO_ID)
                                .retrieve()
                                .bodyToMono(productosDTO.class)
                                .block();
        return producto;
    }





    public List<carrito_compra> BuscarTodoDetalle(){
            return detallerepository.findAll();

    }

    public carrito_compra BuscarUnDetalle(Long PRODUCTO_ID){
        return detallerepository.findById(PRODUCTO_ID).get();
    }

    public carrito_compra GuardarDetalle(carrito_compra carrito_compra){
        return detallerepository.save(carrito_compra);
    }

    public void EliminarDetalle(Long PRODUCTO_ID){
        detallerepository.deleteById(PRODUCTO_ID);

    }




}
