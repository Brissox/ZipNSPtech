package com.nspTECH.carrito_compras.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="DETALLE")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class carrito_compra {

    @Id

    @Column(name= "PRODUCTO_ID",nullable= false , precision = 10)
    private long PRODUCTO_ID;

    @Column(name= "CANTIDAD",nullable= false , precision = 10)
    private long CANTIDAD;
    

    @Column(name = "VALOR",nullable= false , precision = 10)
    private Long VALOR;


}
